package BiblioApp

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}