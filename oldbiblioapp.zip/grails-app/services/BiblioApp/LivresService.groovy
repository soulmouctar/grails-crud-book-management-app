package BiblioApp

import groovy.transform.CompileStatic

@CompileStatic
class LivresService {

    def doSomething() {

    }
}