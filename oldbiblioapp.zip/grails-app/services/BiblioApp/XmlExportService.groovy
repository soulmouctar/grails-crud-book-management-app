package BiblioApp

class XmlExportServiceService {
    def xmlExportOneBook(long id) {
        def livre = Livre.get(id)
        if (!livre) {
            return null
        }
        def xml = new groovy.xml.MarkupBuilder(new StringWriter())
        xml.livre {
            titre(livre.titre)
            auteur(livre.auteur)
            isbn(livre.isbn)
            anneePublication(livre.anneePublication)
            genre(livre.genre)
            description(livre.description)
        }
        return xml.toString()
    }
}