package BiblioApp

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class XmlExportControllerSpec extends Specification implements ControllerUnitTest<XmlExportController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
