package BiblioApp

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class LivresServiceSpec extends Specification implements ServiceUnitTest<LivresService> {

     void "test something"() {
        expect:
        service.doSomething()
     }
}
