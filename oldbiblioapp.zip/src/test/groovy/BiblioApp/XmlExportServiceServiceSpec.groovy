package BiblioApp

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class XmlExportServiceServiceSpec extends Specification implements ServiceUnitTest<XmlExportServiceService> {

     void "test something"() {
        expect:
        service.doSomething()
     }
}
