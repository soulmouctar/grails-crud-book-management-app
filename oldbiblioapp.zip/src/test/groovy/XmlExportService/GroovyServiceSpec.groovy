package XmlExportService

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class GroovyServiceSpec extends Specification implements ServiceUnitTest<GroovyService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
